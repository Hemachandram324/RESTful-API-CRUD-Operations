package com.test.restspi.user_country;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCountryApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserCountryApplication.class, args);
	}

}
